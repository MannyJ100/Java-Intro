
    // get the user inputs
    var value1 = prompt('enter first value'); 
    var value2 = prompt('enter the second value');
    var choice = prompt('Choose your action (a)dd (s)ubtract (m)ultiply (d)ivide') || "a";

