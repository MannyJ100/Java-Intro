console.log('start finding errors');
consoole.log('Error1 Fixed');
aleert('Make some noise!!!!');
var someVariable = 1;
someVariable++;

someVariable++;
someVariable++;

console.log(someVariable);